import CmsPage from "./CmsPage.jsx";

export default function About() {
  return <CmsPage slug="about" variant="default" />;
}
