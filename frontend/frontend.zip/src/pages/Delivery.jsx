import CmsPage from "./CmsPage.jsx";

export default function Delivery() {
  return <CmsPage slug="delivery" variant="compact" />;
}
