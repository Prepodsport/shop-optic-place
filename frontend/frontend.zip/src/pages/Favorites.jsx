import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { useFavorites } from '../context/FavoritesContext';
import ProductGrid from '../components/product/ProductGrid';
import QuickViewModal from '../components/ui/QuickViewModal.jsx';

export default function Favorites() {
  const { items: favoriteIds, clearFavorites } = useFavorites();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quickViewSlug, setQuickViewSlug] = useState(null);

  useEffect(() => {
    fetchFavoriteProducts();
  }, [favoriteIds]);

  const fetchFavoriteProducts = async () => {
    if (favoriteIds.length === 0) {
      setProducts([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // Загружаем товары по ID - передаем ids как параметр
      const idsParam = favoriteIds.join(',');
      const res = await api.get(`/catalog/products/?ids=${idsParam}&page_size=100`);

      // Обрабатываем как пагинированный, так и обычный ответ
      const allProducts = Array.isArray(res.data) ? res.data : (res.data.results || []);

      // Фильтруем по избранным ID на случай если API не поддерживает ids параметр
      const filtered = allProducts.filter((p) => favoriteIds.includes(p.id));
      setProducts(filtered);
    } catch (err) {
      console.error('Ошибка загрузки избранного:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-10 md:py-8 px-4 pb-15 md:pb-10">
      <div className="max-w-[1280px] mx-auto">
        <div className="flex items-center justify-between mb-8 flex-wrap gap-4">
          <h1 className="text-[32px] md:text-[26px] font-bold m-0" style={{ color: 'var(--text)' }}>
            Избранное
          </h1>
          {products.length > 0 && (
            <button
              className="py-2.5 px-5 bg-transparent border border-[var(--border)] rounded-[10px] text-sm cursor-pointer transition-all duration-200 hover:bg-red-50 hover:border-red-200 hover:text-red-500"
              style={{ color: 'var(--muted)' }}
              onClick={clearFavorites}
            >
              Очистить всё
            </button>
          )}
        </div>

        {loading ? (
          <ProductGrid products={[]} loading={true} columns={4} />
        ) : products.length > 0 ? (
          <ProductGrid
            products={products}
            loading={false}
            columns={4}
            onQuickView={setQuickViewSlug}
          />
        ) : (
          <div
            className="text-center py-20 px-5 rounded-2xl border"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <svg
              className="mb-5"
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              style={{ color: 'var(--muted)' }}
            >
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>
            <h3 className="m-0 mb-3 text-[22px]" style={{ color: 'var(--text)' }}>
              В избранном пока пусто
            </h3>
            <p className="m-0 mb-6 text-base" style={{ color: 'var(--muted)' }}>
              Добавляйте понравившиеся товары, нажимая на сердечко
            </p>
            <Link
              to="/catalog"
              className="inline-block py-3.5 px-7 bg-[var(--primary)] text-white no-underline rounded-[10px] font-medium transition-colors duration-200 hover:bg-blue-700 hover:no-underline"
            >
              Перейти в каталог
            </Link>
          </div>
        )}
      </div>

      {quickViewSlug && (
        <QuickViewModal
          productSlug={quickViewSlug}
          onClose={() => setQuickViewSlug(null)}
        />
      )}
    </div>
  );
}
