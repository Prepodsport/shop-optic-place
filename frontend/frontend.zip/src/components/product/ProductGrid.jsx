import ProductCard from "./ProductCard.jsx";

/**
 * Сетка товаров.
 *
 * products может быть:
 * - массивом ([])
 * - объектом пагинации DRF { results: [], count, next, previous }
 *
 * @param {Array|Object} products
 * @param {boolean} loading
 * @param {number} columns
 * @param {function} onQuickView
 * @param {boolean} showEmpty
 */
export default function ProductGrid({
  products,
  loading = false,
  columns,
  onQuickView,
  showEmpty = true,
}) {
  const gridStyle = columns ? { gridTemplateColumns: `repeat(${columns}, 1fr)` } : {};

  // Нормализуем входные данные
  const list = Array.isArray(products) ? products : (products && Array.isArray(products.results) ? products.results : []);

  if (loading) {
    return (
      <div
        className="grid grid-cols-4 xl:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 gap-6 md:gap-4"
        style={gridStyle}
      >
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="rounded-2xl overflow-hidden"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
          >
            <div
              className="pt-[100%] animate-shimmer"
              style={{
                background: 'linear-gradient(90deg, var(--bg) 25%, var(--card) 50%, var(--bg) 75%)',
                backgroundSize: '200% 100%',
              }}
            />
            <div className="p-4">
              <div
                className="h-3 w-2/5 rounded mb-3 animate-shimmer"
                style={{
                  background: 'linear-gradient(90deg, var(--bg) 25%, var(--card) 50%, var(--bg) 75%)',
                  backgroundSize: '200% 100%',
                }}
              />
              <div
                className="h-4 rounded mb-3 animate-shimmer"
                style={{
                  background: 'linear-gradient(90deg, var(--bg) 25%, var(--card) 50%, var(--bg) 75%)',
                  backgroundSize: '200% 100%',
                }}
              />
              <div
                className="h-5 w-3/5 rounded animate-shimmer"
                style={{
                  background: 'linear-gradient(90deg, var(--bg) 25%, var(--card) 50%, var(--bg) 75%)',
                  backgroundSize: '200% 100%',
                }}
              />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!list || list.length === 0) {
    if (!showEmpty) return null;

    return (
      <div className="col-span-full text-center py-15 px-5" style={{ color: 'var(--muted)' }}>
        <svg className="mb-4 opacity-50 mx-auto" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <h3 className="text-xl font-semibold m-0 mb-2" style={{ color: 'var(--text)' }}>
          Товары не найдены
        </h3>
        <p className="m-0 text-[15px]">Попробуйте изменить параметры поиска</p>
      </div>
    );
  }

  return (
    <div
      className="grid grid-cols-4 xl:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 gap-6 md:gap-4"
      style={gridStyle}
    >
      {list.map((product) => (
        <ProductCard key={product.id} product={product} onQuickView={onQuickView} />
      ))}
    </div>
  );
}
